import styles from "./Notes.module.css";

function Chords() {
  return <div>Chords</div>;
}

export default Chords;
