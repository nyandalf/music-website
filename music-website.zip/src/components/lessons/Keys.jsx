import styles from "./Notes.module.css";

function Keys() {
  return <div>Keys</div>;
}

export default Keys;
