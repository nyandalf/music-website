import styles from "./Notes.module.css";

function Scales() {
  return <div>Scales</div>;
}

export default Scales;
